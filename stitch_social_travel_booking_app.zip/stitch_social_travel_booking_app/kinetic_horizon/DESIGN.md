---
name: Kinetic Horizon
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#5a403f'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#8e706f'
  outline-variant: '#e2bebc'
  surface-tint: '#b52330'
  primary: '#b52330'
  on-primary: '#ffffff'
  primary-container: '#ff5a5f'
  on-primary-container: '#61000e'
  inverse-primary: '#ffb3b0'
  secondary: '#585e6c'
  on-secondary: '#ffffff'
  secondary-container: '#dde2f3'
  on-secondary-container: '#5e6473'
  tertiary: '#506169'
  on-tertiary: '#ffffff'
  tertiary-container: '#85969f'
  on-tertiary-container: '#1e2e36'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad8'
  primary-fixed-dim: '#ffb3b0'
  on-primary-fixed: '#410007'
  on-primary-fixed-variant: '#92001b'
  secondary-fixed: '#dde2f3'
  secondary-fixed-dim: '#c1c6d7'
  on-secondary-fixed: '#161c27'
  on-secondary-fixed-variant: '#414754'
  tertiary-fixed: '#d4e5ef'
  tertiary-fixed-dim: '#b8c9d3'
  on-tertiary-fixed: '#0d1e25'
  on-tertiary-fixed-variant: '#394951'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-xl:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an architectural, gallery-grade discovery interface for discerning travelers. The aesthetic pairs disciplined minimalism with atmospheric warmth, stripping away extraneous ornamentation to let photographic content, rich typography, and spatial geometry lead the user experience.

### Visual Character
- **Architectural Rigor:** Form follows intent. Interfaces use structured layouts, balanced negative space, and disciplined alignment rather than ornamental patterns or decorative dividers.
- **Editorial Clarity:** High-contrast typographic hierarchy organizes complex travel itineraries and real-time search filters into calm, legible viewports.
- **Controlled Focus:** Vibrant color is applied sparingly as a surgical beacon for user interaction, maintaining an uncluttered, high-end editorial atmosphere.

## Colors

The palette establishes an ultra-clean, museum-like canvas where content is elevated through crisp tonal separation and selective, deliberate accents.

### Color Roles & Application
- **Primary Accent (`#FF5A5F`):** A bright salmon-cherry hue reserved exclusively for high-priority interactive touchpoints: primary booking actions, saved/favorite states, active tab indicators, and search highlights. It must never be applied to broad structural backgrounds.
- **Deep Slate (`#1A202C`):** Used for headlines, prominent metrics, display text, and high-impact micro-copy. Delivers structural gravity and contrast against light surfaces.
- **Dark Blue-Gray (`#37474F`):** The foundational tone for long-form body text, subtitles, secondary icons, and structural hairline borders (`#E2E8F0` or `#37474F` at 12% alpha). Ensures effortless readability without harsh pitch-black contrast.
- **Canvas Base (`#F8F9FA`):** An expansive, subtly warm light neutral used for outer viewport backdrops, app scaffolding, and passive layout gutters.
- **Surface Pure (`#FFFFFF`):** High-clarity white allocated to interactive cards, popovers, navigation bars, bottom sheets, and input fields.

## Typography

The type scale combines the technical, geometric personality of Space Grotesk with the rational legibility of Inter.

- **Display & Headlines (Space Grotesk):** Gives destination names, editorial collection headers, and pricing summaries an architectural presence. Tight negative letter spacing reinforces crispness.
- **Body & Captions (Inter):** Sets descriptions, facility disclosures, and travel notes with neutral readability.
- **Labels & Micro-Copy (Space Grotesk):** Set uppercase or title-cased with slight positive tracking for chips, status tags, form labels, and metric identifiers.

## Layout & Spacing

Layouts follow an open fluid-grid structure that prioritizes generous negative space to minimize cognitive fatigue during open-ended travel discovery.

### Grid & Breakpoints
- **Desktop (≥1280px):** 12-column fluid grid, 48px canvas margin (`margin`), 24px column gutter (`gutter`). Maximum content constraint capped at 1440px for comfortable panoramic viewing.
- **Tablet (768px - 1279px):** 8-column fluid grid, 32px canvas margin (`margin-tablet`), 20px column gutter.
- **Mobile (<768px):** 4-column fluid grid, 16px canvas margin (`margin-mobile`), 16px column gutter (`gutter-mobile`).

### Rhythms & Whitespace
Vertical rhythm relies on larger scale increments (`space-lg` to `space-xl`) between distinct thematic groups (e.g., photo galleries, destination highlights, pricing breakdowns) to maintain an airy, clutter-free rhythm. Internal card elements utilize compact tokens (`space-xs` to `space-sm`) to keep metadata groupings coherent and scannable.

## Elevation & Depth

Visual hierarchy is maintained through flat, architectural layering and low-contrast surface outlines rather than dramatic dropshadows.

### Layering Philosophy
- **Base Canvas:** The foundation (`#F8F9FA`) hosts primary feeds, listing grids, and overview views.
- **Surface Elevation (Cards & Panels):** Constructed using `#FFFFFF` paired with a sharp, fine border (`1px solid rgba(55, 71, 79, 0.12)`).
- **Ambient Focus:** Hover or active selection states abandon harsh black shadows. They adopt an ultra-diffused atmospheric lift: `0px 8px 24px -4px rgba(26, 32, 44, 0.06), 0px 1px 2px 0px rgba(26, 32, 44, 0.04)`.
- **Modals & Overlays:** Bottom sheets, search dropdowns, and lightboxes use pure white surfaces, crisp hairlines, and a muted, semi-transparent veil (`rgba(26, 32, 44, 0.40)` with `backdrop-filter: blur(8px)`).

## Shapes

The design language strictly rejects fully rounded pill shapes, adopting a uniform 8px radius across all containers, inputs, interactive controls, and media viewports.

### Architectural Corners
- **Standard Geometry (8px):** Applied to cards, input fields, interactive tags, buttons, image thumbnails, and segmented pickers.
- **Structural Uniformity:** Consistent 8px corners across both small controls and large cards create a cohesive geometric grid, giving the product an editorial, modern product feel.

## Components

### Buttons
- **Primary:** Background `#FF5A5F`, text `#FFFFFF`, 8px border radius, font `label-lg`. Zero elevation in resting state; subtle opacity reduction (`0.92`) on hover. Height: 44px (desktop), 48px (mobile touch target).
- **Secondary / Outline:** Background `#FFFFFF`, border `1px solid rgba(55, 71, 79, 0.2)`, text `#1A202C`, 8px border radius. Hover introduces background `#F8F9FA` and border `#1A202C`.
- **Ghost:** Background transparent, text `#37474F`, 8px border radius. Used for auxiliary pagination and contextual feed actions.

### Cards (Feed & Discovery)
- Pure `#FFFFFF` background, uniform 8px corner radius, framed by a `1px solid rgba(55, 71, 79, 0.1)` boundary.
- Media elements within cards must fill the top perimeter with matching top 8px corners and a 16:10 or 4:3 fixed aspect ratio.
- Internal content padding strictly set to `16px` (`space-md`). Clutter is avoided: display destination, distance/date line, price per night, and a single subtle bookmark icon in the top-right corner.

### Chips & Filter Tags
- **Default State:** Background `#FFFFFF`, border `1px solid rgba(55, 71, 79, 0.15)`, text `#37474F`, 8px corner radius (strictly no pill rounding), font `label-md`.
- **Active / Selected State:** Background `#1A202C`, border `1px solid #1A202C`, text `#FFFFFF`.
- Padding: 6px 14px.

### Input Fields & Search Bars
- Floating or embedded search inputs use `#FFFFFF`, 8px corners, and `1px solid rgba(55, 71, 79, 0.15)`.
- Active focus state: Hairline border shifts to `#1A202C` with an outer ring of `2px solid rgba(255, 90, 95, 0.25)`.
- Input labels use Space Grotesk `label-sm` in `#37474F`, while placeholder text uses Inter `body-md` in `#37474F` at 50% opacity.

### Checkboxes & Radios
- Size: 18px × 18px with 4px border radius for checkboxes; radios remain circular for standard semantic distinction.
- Border: `1.5px solid rgba(55, 71, 79, 0.3)`.
- Checked state: Filled with `#FF5A5F` and inset white checkmark/dot.

### Feed Badges & Status Indicators
- Rectangular with 8px radius. Background `#F8F9FA` or `#FFFFFF` with fine borders.
- Never use bright fills for informational badges; only use `#FF5A5F` for live availability alerts or promotional status flags.